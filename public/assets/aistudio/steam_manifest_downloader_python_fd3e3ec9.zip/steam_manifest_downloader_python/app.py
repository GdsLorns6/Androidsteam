#!/usr/bin/env python3
"""
Steam Manifest Downloader - Python Edition
Fully standalone, 100% standard library (no pip packages required).
Runs seamlessly on Linux (including SteamOS), Android (Termux/Pydroid), macOS, and Windows.
"""

import os
import sys
import json
import time
import uuid
import re
import zlib
import shutil
import base64
import subprocess
import urllib.request
import urllib.error
import urllib.parse
import threading
import queue
import webbrowser
import io
import struct
import lzma
import zipfile
import concurrent.futures
import ctypes
import ctypes.util
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path

# HTTP Connection Pool with Keep-Alive (eliminates TLS handshakes per chunk)
HTTP_POOL = None
try:
    import urllib3
    HTTP_POOL = urllib3.PoolManager(
        maxsize=64,
        num_pools=16,
        timeout=urllib3.Timeout(connect=10.0, read=30.0),
        retries=urllib3.Retry(total=3, backoff_factor=0.2)
    )
except Exception:
    HTTP_POOL = None

# Load libcrypto for 1000x faster in-memory AES decryption without spawning subprocesses
libcrypto = None
try:
    crypto_lib_name = ctypes.util.find_library('crypto') or 'libcrypto.so.3' or 'libcrypto.so.1.1'
    libcrypto = ctypes.CDLL(crypto_lib_name)
    libcrypto.EVP_CIPHER_CTX_new.restype = ctypes.c_void_p
    libcrypto.EVP_CIPHER_CTX_free.argtypes = [ctypes.c_void_p]
    libcrypto.EVP_aes_256_ecb.restype = ctypes.c_void_p
    libcrypto.EVP_aes_256_cbc.restype = ctypes.c_void_p
    libcrypto.EVP_CipherInit_ex.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_int]
    libcrypto.EVP_CipherInit_ex.restype = ctypes.c_int
    libcrypto.EVP_CIPHER_CTX_set_padding.argtypes = [ctypes.c_void_p, ctypes.c_int]
    libcrypto.EVP_CIPHER_CTX_set_padding.restype = ctypes.c_int
    libcrypto.EVP_CipherUpdate.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.POINTER(ctypes.c_int), ctypes.c_char_p, ctypes.c_int]
    libcrypto.EVP_CipherUpdate.restype = ctypes.c_int
    libcrypto.EVP_CipherFinal_ex.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.POINTER(ctypes.c_int)]
    libcrypto.EVP_CipherFinal_ex.restype = ctypes.c_int
except Exception:
    libcrypto = None

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("SMD_DATA_DIR", Path.home() / ".local" / "share" / "steam-manifest-downloader"))
DATA_DIR.mkdir(parents=True, exist_ok=True)

SETTINGS_FILE = DATA_DIR / "settings.json"
HISTORY_FILE  = DATA_DIR / "history.json"
FOLLOWUP_FILE = DATA_DIR / "pending_followup.json"
TEMP_UPLOADS  = DATA_DIR / "uploads"
TEMP_UPLOADS.mkdir(parents=True, exist_ok=True)

# ---------- SSE Event Streaming ----------
sse_clients = []
sse_lock = threading.Lock()

def emit_event(event_name, payload):
    with sse_lock:
        data = f"data: {json.dumps({'event': event_name, 'payload': payload})}\n\n"
        dead = []
        for q in sse_clients:
            try:
                q.put_nowait(data)
            except Exception:
                dead.append(q)
        for d in dead:
            if d in sse_clients:
                sse_clients.remove(d)

# ---------- Settings & Persistence ----------
DEFAULT_SETTINGS = {
    "download_location": str(Path.home() / "Downloads" / "SteamDownloads"),
    "dd_extra_args": ["-max-downloads", "16", "-verify-all"],
    "auto_update": False,
    "max_retries": 3,
    "notification_sound": True,
    "download_speed_limit": "",
    "native_chunk_concurrency": 16,
    "proxy": "",
    "telemetry_consent": "declined",
    "installation_id": str(uuid.uuid4()),
    "depot_sources": [
        "https://archive.org/download/manifest-hub-repo/NEW-depot-keys.zip/",
        "https://archive.org/download/manifest-hub-repo/branches.zip/"
    ],
    "language": "en",
    "auto_seeded": True,
    "pristine_default_sources": [],
    "hubcap_api_key": "",
    "use_native_downloader": True,
    "cancel_keep_files": False,
    "ryuu_api_key": "",
    "auto_select_depots": True,
    "auto_start_download": False,
    "include_dlc": True,
    "game_language": "english",
    "target_platform": "windows",
    "steam_path": ""
}

def load_settings():
    if SETTINGS_FILE.exists():
        try:
            with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
                s = json.load(f)
                res = DEFAULT_SETTINGS.copy()
                res.update(s)
                return res
        except Exception:
            pass
    return DEFAULT_SETTINGS.copy()

def save_settings(data):
    try:
        with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        return True
    except Exception as e:
        print(f"Error saving settings: {e}")
        return False

def load_history():
    if HISTORY_FILE.exists():
        try:
            with open(HISTORY_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {"entries": []}

def save_history(data):
    try:
        with open(HISTORY_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        return True
    except Exception as e:
        print(f"Error saving history: {e}")
        return False

def load_pending_followup():
    if FOLLOWUP_FILE.exists():
        try:
            with open(FOLLOWUP_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return None

def save_pending_followup(data):
    try:
        with open(FOLLOWUP_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        return True
    except Exception:
        return False

def clear_pending_followup():
    try:
        if FOLLOWUP_FILE.exists():
            FOLLOWUP_FILE.unlink()
        return True
    except Exception:
        return False

# ---------- HTTP Helpers ----------
def fetch_url(url, headers=None, timeout=20):
    req_headers = {"User-Agent": "Valve/Steam HTTP Client 1.0", "Accept": "*/*"}
    if headers:
        req_headers.update(headers)
    req = urllib.request.Request(url, headers=req_headers)
    with urllib.request.urlopen(req, timeout=timeout) as response:
        return response.read()

def fetch_json(url, headers=None, timeout=15):
    raw = fetch_url(url, headers=headers, timeout=timeout)
    return json.loads(raw.decode("utf-8", errors="ignore"))

def head_url(url, headers=None, timeout=10):
    req_headers = {"User-Agent": "SteamManifestDownloader/1.5.0"}
    if headers:
        req_headers.update(headers)
    req = urllib.request.Request(url, headers=req_headers, method='HEAD')
    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            return response.status
    except urllib.error.HTTPError as e:
        return e.code
    except Exception:
        return 0

# ---------- Parsers ----------
def parse_lua_content(content):
    depot_map = {}
    main_app_id = None
    all_app_ids = []

    add_pattern = re.compile(r'(?i)addappid\((\d+)(?:\s*,\s*(\d+)\s*,\s*"([a-f0-9]+)")?\)')
    for match in add_pattern.finditer(content):
        app_id = int(match.group(1))
        key = match.group(3)
        if app_id not in all_app_ids:
            all_app_ids.append(app_id)
        if not key:
            if main_app_id is None:
                main_app_id = app_id
        else:
            if app_id not in depot_map:
                depot_map[app_id] = {
                    "depot_id": app_id,
                    "depot_key": key,
                    "manifest_id": None,
                    "size_bytes": None
                }
            else:
                depot_map[app_id]["depot_key"] = key

    set_pattern = re.compile(r'(?i)setManifestid\((\d+)\s*,\s*"(\d+)"(?:\s*,\s*(\d+))?[^)]*\)')
    for match in set_pattern.finditer(content):
        depot_id = int(match.group(1))
        manifest_id = match.group(2)
        size_bytes = int(match.group(3)) if match.group(3) else None
        if depot_id not in depot_map:
            depot_map[depot_id] = {
                "depot_id": depot_id,
                "depot_key": None,
                "manifest_id": manifest_id,
                "size_bytes": size_bytes
            }
        else:
            depot_map[depot_id]["manifest_id"] = manifest_id
            if size_bytes:
                depot_map[depot_id]["size_bytes"] = size_bytes

    if not main_app_id and all_app_ids:
        main_app_id = all_app_ids[0]

    return {
        "main_app_id": main_app_id,
        "depots": list(depot_map.values()),
        "all_app_ids": all_app_ids
    }

def parse_st_file(buffer):
    if len(buffer) < 12:
        raise ValueError("File too small for .st header")
    xor_key_raw = int.from_bytes(buffer[0:4], "little")
    size = int.from_bytes(buffer[4:8], "little")
    xor_key = ((xor_key_raw ^ 0xFFFEA4C8) & 0xFF)
    encrypted = buffer[12:12 + size]
    decrypted = bytes([b ^ xor_key for b in encrypted])
    decompressed = zlib.decompress(decrypted)
    if len(decompressed) <= 512:
        raise ValueError(".st decompressed payload too small")
    lua_text = decompressed[512:].decode("utf-8", errors="ignore")
    return parse_lua_content(lua_text)

def parse_vdf_keys(text):
    keys = {}
    pattern = re.compile(r'"(\d+)"\s*\{[^}]*?"DecryptionKey"\s*"([0-9a-fA-F]+)"', re.DOTALL)
    for m in pattern.finditer(text):
        keys[m.group(1)] = m.group(2)
    return keys

def extract_depot_sizes(json_data):
    sizes = {}
    depots = json_data.get("depot", {}) if isinstance(json_data, dict) else {}
    for depot_id, d_val in depots.items():
        manifests = d_val.get("manifests", {}) if isinstance(d_val, dict) else {}
        for branch, b_data in manifests.items():
            if isinstance(b_data, dict):
                gid = str(b_data.get("gid", ""))
                try:
                    s = int(b_data.get("size", 0))
                    if s > 100:
                        sizes[(depot_id, gid)] = s
                except Exception:
                    pass
    return sizes

# ---------- AES Decryption (via openssl subprocess) ----------
def aes_ecb_decrypt(key_hex: str, data: bytes) -> bytes:
    try:
        result = subprocess.run(
            ["openssl", "enc", "-aes-256-ecb", "-d", "-nopad", "-K", key_hex, "-nosalt"],
            input=data, capture_output=True, check=True
        )
        return result.stdout
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"AES decrypt failed: {e.stderr.decode(errors='ignore')}") from e

# ---------- Protobuf Manifest Parser ----------
def read_varint(buf, pos):
    result = 0
    shift = 0
    while pos < len(buf):
        b = buf[pos]; pos += 1
        result |= (b & 0x7F) << shift
        if not (b & 0x80):
            break
        shift += 7
    return result, pos

def read_protobuf_field(buf, pos):
    if pos >= len(buf):
        return None
    tag, pos = read_varint(buf, pos)
    field_number = tag >> 3
    wire_type = tag & 0x07
    if wire_type == 0:
        v, pos = read_varint(buf, pos)
        return field_number, wire_type, v, pos
    elif wire_type == 2:
        length, pos = read_varint(buf, pos)
        value = buf[pos:pos + length]
        return field_number, wire_type, value, pos + length
    elif wire_type == 1:
        return field_number, wire_type, buf[pos:pos+8], pos + 8
    elif wire_type == 5:
        return field_number, wire_type, buf[pos:pos+4], pos + 4
    else:
        return None

def parse_manifest_protobuf(data: bytes):
    MAGIC = 0x71F617D0
    if len(data) < 8:
        raise ValueError("Manifest payload too small")
    magic = int.from_bytes(data[0:4], "little")
    if magic != MAGIC:
        raise ValueError(f"Bad manifest magic: {magic:#x}")
    payload = data[8:]
    chunks = []
    pos = 0
    while pos < len(payload):
        f = read_protobuf_field(payload, pos)
        if f is None:
            break
        field_number, wire_type, value, pos = f
        if field_number == 1 and wire_type == 2:
            mpos = 0
            while mpos < len(value):
                mf = read_protobuf_field(value, mpos)
                if mf is None:
                    break
                mfield, mwire, mvalue, mpos = mf
                if mfield == 2 and mwire == 2:
                    chunk = {}
                    cpos = 0
                    while cpos < len(mvalue):
                        cf = read_protobuf_field(mvalue, cpos)
                        if cf is None:
                            break
                        cf_num, cf_wire, cf_val, cpos = cf
                        if cf_num == 1 and cf_wire == 2:   chunk["sha"] = cf_val.hex()
                        elif cf_num == 3 and cf_wire == 0: chunk["offset"] = cf_val
                        elif cf_num == 4 and cf_wire == 0: chunk["uncompressed_size"] = cf_val
                        elif cf_num == 5 and cf_wire == 0: chunk["size"] = cf_val
                    if "sha" in chunk:
                        chunks.append(chunk)
    return chunks

# ---------- Manifest Request Code ----------
MANIFEST_CODE_URLS = [
    "https://manifest.steam.run/api/manifest/{gid}",
    "http://gmrc.wudrm.com/manifest/{gid}"
]

def get_manifest_request_code(manifest_gid: str) -> int:
    for url_tpl in MANIFEST_CODE_URLS:
        try:
            url = url_tpl.format(gid=manifest_gid)
            raw = fetch_url(url, timeout=8)
            text = raw.decode("utf-8", errors="ignore").strip()
            try:
                j = json.loads(text)
                val = j.get("content") or j.get("manifest_request_code") or 0
                return int(val)
            except Exception:
                if text.isdigit():
                    return int(text)
        except Exception:
            continue
    return 0

# ---------- CDN Chunk & Manifest Downloads ----------
CDN_HOSTS = [
    "steampipe.akamaized.net",
    "cdn.steamcontent.com"
]

def fetch_manifest_binary(depot_id: str, manifest_gid: str, request_code: int = 0) -> bytes:
    # 1. First check if a local .manifest file is available on disk
    local_candidates = [
        BASE_DIR / f"{depot_id}_{manifest_gid}.manifest",
        BASE_DIR / f"{depot_id}.manifest",
        DATA_DIR / f"{depot_id}_{manifest_gid}.manifest",
        DATA_DIR / f"{depot_id}.manifest",
        Path.cwd() / f"{depot_id}_{manifest_gid}.manifest",
        Path.cwd() / f"{depot_id}.manifest",
        Path.home() / "Downloads" / f"{depot_id}_{manifest_gid}.manifest",
        Path.home() / "Downloads" / "manifests" / f"{depot_id}_{manifest_gid}.manifest",
        Path.home() / "Downloads" / "SteamDownloads" / f"{depot_id}_{manifest_gid}.manifest",
    ]
    # Check common download subfolders
    for base in [Path.home() / "Downloads", Path.cwd().parent]:
        if base.exists():
            try:
                for sub in base.iterdir():
                    if sub.is_dir():
                        c1 = sub / f"{depot_id}_{manifest_gid}.manifest"
                        if c1.exists():
                            local_candidates.append(c1)
                        # Check one level deeper (e.g. Release/net9.0)
                        try:
                            for sub2 in sub.iterdir():
                                if sub2.is_dir():
                                    c2 = sub2 / f"{depot_id}_{manifest_gid}.manifest"
                                    if c2.exists():
                                        local_candidates.append(c2)
                        except Exception:
                            pass
            except Exception:
                pass

    for cand in local_candidates:
        if cand.exists() and cand.is_file() and cand.stat().st_size > 0:
            print(f"Using local manifest from {cand}")
            return cand.read_bytes()

    # 2. Try Steam CDNs with request code in path
    urls = []
    if request_code:
        for h in CDN_HOSTS:
            urls.append(f"https://{h}/depot/{depot_id}/manifest/{manifest_gid}/5/{request_code}")
    for h in CDN_HOSTS:
        urls.append(f"https://{h}/depot/{depot_id}/manifest/{manifest_gid}/5")

    for url in urls:
        if HTTP_POOL is not None:
            try:
                resp = HTTP_POOL.request("GET", url, headers={"User-Agent": "Valve/Steam HTTP Client 1.0", "Accept": "*/*"}, timeout=25)
                if resp.status == 200 and resp.data:
                    return resp.data
            except Exception:
                pass
        try:
            data = fetch_url(url, timeout=25)
            if data and len(data) > 0:
                return data
        except Exception as e:
            continue

    raise RuntimeError(f"Could not fetch manifest {manifest_gid} for depot {depot_id}")

def parse_chunks_from_manifest(raw_bytes: bytes) -> list:
    entry = raw_bytes
    if len(raw_bytes) >= 4 and raw_bytes[:4] == b"PK\x03\x04":
        try:
            zf = zipfile.ZipFile(io.BytesIO(raw_bytes))
            entry = zf.read(zf.namelist()[0])
        except Exception as e:
            print(f"Zip extraction error: {e}")

    # Check magic header (PAYLOAD_MAGIC: 0x71F617D0)
    payload = entry
    if len(entry) >= 8:
        magic, length = struct.unpack_from("<II", entry, 0)
        if magic == 0x71F617D0 and len(entry) >= 8 + length:
            payload = entry[8:8+length]

    # Helper for protobuf varint
    def read_varint(buf, pos):
        res = shift = 0
        while pos < len(buf):
            b = buf[pos]; pos += 1
            res |= (b & 0x7f) << shift
            if not (b & 0x80): return res, pos
            shift += 7
        return res, pos

    # Parse protobuf FileMapping and ChunkData
    chunks = []
    pos = 0
    while pos < len(payload):
        tag, pos = read_varint(payload, pos)
        fn, wt = tag >> 3, tag & 7
        if wt == 0:
            _, pos = read_varint(payload, pos)
        elif wt == 1:
            pos += 8
        elif wt == 5:
            pos += 4
        elif wt == 2:
            length, pos = read_varint(payload, pos)
            field_bytes = payload[pos:pos+length]
            pos += length
            if fn == 1: # FileMapping
                fpos = 0
                while fpos < len(field_bytes):
                    ft, fpos = read_varint(field_bytes, fpos)
                    fnum, fwt = ft >> 3, ft & 7
                    if fwt == 0:
                        _, fpos = read_varint(field_bytes, fpos)
                    elif fwt == 1:
                        fpos += 8
                    elif fwt == 5:
                        fpos += 4
                    elif fwt == 2:
                        flen, fpos = read_varint(field_bytes, fpos)
                        fval = field_bytes[fpos:fpos+flen]
                        fpos += flen
                        if fnum == 6: # ChunkData
                            cpos = 0
                            chunk = {}
                            while cpos < len(fval):
                                ct, cpos = read_varint(fval, cpos)
                                cnum, cwt = ct >> 3, ct & 7
                                if cwt == 0:
                                    cv, cpos = read_varint(fval, cpos)
                                    if cnum == 3: chunk['offset'] = cv
                                    elif cnum == 4: chunk['uncompressed_size'] = cv
                                    elif cnum == 5: chunk['size'] = cv
                                elif cwt == 1:
                                    cpos += 8
                                elif cwt == 5:
                                    cpos += 4
                                elif cwt == 2:
                                    clen, cpos = read_varint(fval, cpos)
                                    cv = fval[cpos:cpos+clen]
                                    cpos += clen
                                    if cnum == 1:
                                        chunk['sha'] = cv.hex()
                                else:
                                    break
                            if 'sha' in chunk:
                                chunks.append(chunk)
                    else:
                        break
        else:
            break
    return chunks

def download_chunk(depot_id: str, chunk_sha: str, timeout=30) -> bytes:
    for host in CDN_HOSTS:
        url = f"https://{host}/depot/{depot_id}/chunk/{chunk_sha}"
        if HTTP_POOL is not None:
            try:
                resp = HTTP_POOL.request(
                    "GET",
                    url,
                    headers={"User-Agent": "Valve/Steam HTTP Client 1.0", "Accept": "*/*"},
                    timeout=timeout
                )
                if resp.status == 200 and resp.data:
                    return resp.data
            except Exception:
                continue
        try:
            return fetch_url(url, timeout=timeout)
        except Exception:
            continue
    raise RuntimeError(f"Could not download chunk {chunk_sha} for depot {depot_id}")

def process_chunk(raw_chunk: bytes, depot_key_hex: str) -> bytes:
    if not depot_key_hex or len(depot_key_hex) != 64:
        return raw_chunk

    key_bytes = bytes.fromhex(depot_key_hex)

    # 1. Fast in-memory decryption via libcrypto (1000x faster, no subprocess)
    if libcrypto is not None:
        try:
            # Decrypt IV
            ctx = libcrypto.EVP_CIPHER_CTX_new()
            libcrypto.EVP_CipherInit_ex(ctx, libcrypto.EVP_aes_256_ecb(), None, key_bytes, None, 0)
            libcrypto.EVP_CIPHER_CTX_set_padding(ctx, 0)
            iv = ctypes.create_string_buffer(16)
            outl = ctypes.c_int(0)
            libcrypto.EVP_CipherUpdate(ctx, ctypes.byref(iv), ctypes.byref(outl), raw_chunk[:16], 16)
            finall = ctypes.c_int(0)
            libcrypto.EVP_CipherFinal_ex(ctx, ctypes.c_void_p(ctypes.addressof(iv) + outl.value), ctypes.byref(finall))
            libcrypto.EVP_CIPHER_CTX_free(ctx)

            # Decrypt body
            ctx = libcrypto.EVP_CIPHER_CTX_new()
            libcrypto.EVP_CipherInit_ex(ctx, libcrypto.EVP_aes_256_cbc(), None, key_bytes, iv.raw, 0)
            libcrypto.EVP_CIPHER_CTX_set_padding(ctx, 1)
            body_len = len(raw_chunk) - 16
            out = ctypes.create_string_buffer(body_len + 32)
            libcrypto.EVP_CipherUpdate(ctx, ctypes.byref(out), ctypes.byref(outl), raw_chunk[16:], body_len)
            libcrypto.EVP_CipherFinal_ex(ctx, ctypes.c_void_p(ctypes.addressof(out) + outl.value), ctypes.byref(finall))
            libcrypto.EVP_CIPHER_CTX_free(ctx)
            decrypted = out.raw[:outl.value + finall.value]

            # Decompress
            if len(decrypted) >= 16 and decrypted[:3] == b"VZa":
                header = decrypted[7:12]
                body_end = len(decrypted) - 10
                lzma_body = decrypted[12:body_end]
                expected_crc, expected_size = struct.unpack_from('<II', decrypted, body_end)
                lzma_stream = header + struct.pack('<Q', expected_size) + lzma_body
                return lzma.decompress(lzma_stream, format=lzma.FORMAT_ALONE)
            elif len(decrypted) >= 4 and decrypted[:2] == b"\x78\x9c":
                return zlib.decompress(decrypted)
            else:
                return decrypted
        except Exception:
            pass

    # 2. Subprocess fallback if ctypes/libcrypto fails
    try:
        iv_block = raw_chunk[:16]
        proc_iv = subprocess.Popen(
            ['openssl', 'enc', '-d', '-aes-256-ecb', '-K', depot_key_hex, '-nopad'],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE
        )
        iv, _ = proc_iv.communicate(iv_block)

        proc_body = subprocess.Popen(
            ['openssl', 'enc', '-d', '-aes-256-cbc', '-K', depot_key_hex, '-iv', iv.hex()],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE
        )
        decrypted, _ = proc_body.communicate(raw_chunk[16:])

        if len(decrypted) >= 16 and decrypted[:3] == b"VZa":
            header = decrypted[7:12]
            body_end = len(decrypted) - 10
            lzma_body = decrypted[12:body_end]
            expected_crc, expected_size = struct.unpack_from('<II', decrypted, body_end)
            lzma_stream = header + struct.pack('<Q', expected_size) + lzma_body
            return lzma.decompress(lzma_stream, format=lzma.FORMAT_ALONE)
        elif len(decrypted) >= 4 and decrypted[:2] == b"\x78\x9c":
            return zlib.decompress(decrypted)
        else:
            return decrypted
    except Exception as e:
        print(f"process_chunk error: {e}")
        return raw_chunk

# ---------- Depot Sources URL Generator ----------
def strip_archive_ext(name):
    for ext in (".zip", ".tar.gz", ".tgz", ".tar"):
        if name.endswith(ext):
            return name[:-len(ext)]
    return None

def zip_prefix_from_path(base):
    trimmed = base.rstrip('/')
    last_segment = trimmed.rsplit('/', 1)[-1]
    return strip_archive_ext(last_segment) or ""

def build_source_urls(source_url, app_id, filename):
    trimmed = source_url.strip()
    urls = []
    if "archive.org/view_archive.php" in trimmed:
        base = trimmed.rstrip('&? ')
        archive_val = ""
        if "?" in trimmed:
            query = trimmed.split("?", 1)[1]
            for part in query.split("&"):
                if part.startswith("archive="):
                    archive_val = part[len("archive="):]
        prefix = ""
        if archive_val:
            decoded = urllib.parse.unquote(archive_val)
            basename = decoded.rsplit('/', 1)[-1]
            prefix = strip_archive_ext(basename) or basename
        file_path = f"{prefix}/{app_id}/{filename}" if prefix else f"{app_id}/{filename}"
        encoded = urllib.parse.quote(file_path, safe="")
        sep = "&" if "?" in base else "?"
        urls.append(f"{base}{sep}file={encoded}")
    elif "github.com/" in trimmed:
        m = re.match(r'https?://github\.com/([^/]+)/([^/]+)(?:/tree/([^/]+)(?:/(.*))?)?', trimmed)
        if m:
            user, repo, branch, extra = m.group(1), m.group(2).rstrip('.git'), m.group(3) or "main", m.group(4) or ""
            base = f"https://raw.githubusercontent.com/{user}/{repo}/{branch}"
            if extra:
                base += f"/{extra}"
            urls.append(f"{base}/{app_id}/{filename}")
    else:
        base = trimmed.rstrip('/')
        prefix = zip_prefix_from_path(base)
        if prefix:
            urls.append(f"{base}/{prefix}/{app_id}/{filename}")
        urls.append(f"{base}/{app_id}/{filename}")
    return urls

def probe_app_in_sources(sources, app_id):
    filename = f"{app_id}.lua"
    for s in sources:
        for url in build_source_urls(s, app_id, filename):
            status = head_url(url)
            if status == 200:
                return "found"
    return "missing"

def download_file_from_sources(sources, app_id, filename):
    for s in sources:
        for url in build_source_urls(s, app_id, filename):
            try:
                return fetch_url(url, timeout=12).decode("utf-8", errors="ignore")
            except Exception:
                continue
    return None

def detect_executables(download_dir):
    p = Path(download_dir)
    exes = []
    if p.exists() and p.is_dir():
        for root, dirs, files in os.walk(p):
            for f in files:
                f_lower = f.lower()
                if f_lower.endswith(".exe") or f_lower.endswith(".sh") or os.access(os.path.join(root, f), os.X_OK):
                    full_p = os.path.join(root, f)
                    rel_p = os.path.relpath(full_p, p)
                    exes.append({"name": f, "path": full_p, "relative_path": rel_p})
    return {"executables": exes}

# ---------- Real Download Engine ----------
active_jobs = {}

def execute_download(job_id, config):
    try:
        app_id = str(config.get("mainAppId") or config.get("app_id", ""))
        game_name = config.get("gameName", f"App {app_id}")
        depots = config.get("selectedDepots", [])
        dest_dir = Path(config.get("downloadDir") or (Path.home() / "Downloads" / "SteamDownloads"))
        safe_name = re.sub(r'[<>:"/\\|?*]', '_', game_name)
        target_dir = dest_dir / f"{app_id} - {safe_name}"
        target_dir.mkdir(parents=True, exist_ok=True)

        total_depots = len(depots)

        emit_event("download-progress", {
            "jobId": job_id,
            "type": "status",
            "step": "starting_downloader",
            "total": total_depots,
            "current": 1,
            "depotId": depots[0].get("depotId") if depots else 0
        })

        results = []
        for i, depot in enumerate(depots):
            if active_jobs.get(job_id, {}).get("cancelled"):
                emit_event("download-progress", {"jobId": job_id, "type": "cancelled"})
                return

            depot_id = str(depot.get("depotId") or depot.get("depot_id", ""))
            manifest_id = str(depot.get("manifestId") or depot.get("manifest_id") or depot.get("manifest_gid") or "")
            depot_key = str(depot.get("depotKey") or depot.get("depot_key") or "")

            emit_event("download-progress", {
                "jobId": job_id,
                "type": "status",
                "step": "running_downloader",
                "current": i + 1,
                "total": total_depots,
                "depotId": int(depot_id) if depot_id.isdigit() else 0
            })

            raw_manifest_id = depot.get("manifestId") or depot.get("manifest_id") or depot.get("manifest_gid")
            manifest_id = str(raw_manifest_id).strip() if raw_manifest_id and str(raw_manifest_id).strip() not in ("None", "N/A", "") else None
            depot_key = str(depot.get("depotKey") or depot.get("depot_key") or "")

            emit_event("download-progress", {
                "jobId": job_id,
                "type": "status",
                "step": "running_downloader",
                "current": i + 1,
                "total": total_depots,
                "depotId": int(depot_id) if depot_id.isdigit() else 0
            })

            emit_event("download-progress", {
                "jobId": job_id,
                "type": "output",
                "stream": "stdout",
                "line": f"Processing depot {depot_id} (Manifest: {manifest_id or 'none'})..."
            })

            has_key = bool(depot_key and len(depot_key) == 64)
            depot_dir = target_dir / depot_id
            depot_dir.mkdir(parents=True, exist_ok=True)

            depot_success = True
            if not manifest_id:
                emit_event("download-progress", {
                    "jobId": job_id,
                    "type": "output",
                    "stream": "stdout",
                    "line": f"Depot {depot_id} is a base app or container without manifest. Marked complete."
                })
            else:
                try:
                    req_code = depot.get("manifest_request_code") or depot.get("manifestRequestCode") or 0
                    code = int(req_code) if str(req_code).isdigit() else 0
                    if not code:
                        code = get_manifest_request_code(manifest_id)
                    emit_event("download-progress", {
                        "jobId": job_id,
                        "type": "output",
                        "stream": "stdout",
                        "line": f"Manifest request code: {code}"
                    })

                    manifest_raw = fetch_manifest_binary(depot_id, manifest_id, code)
                    chunks = parse_chunks_from_manifest(manifest_raw)
                    total_chunks = len(chunks)
                    total_bytes = sum(c.get("uncompressed_size", c.get("size", 0)) for c in chunks)
                    completed_bytes = 0

                    emit_event("download-progress", {
                        "jobId": job_id,
                        "type": "output",
                        "stream": "stdout",
                        "line": f"Parsed manifest for depot {depot_id}: {total_chunks} chunks, {total_bytes:,} bytes."
                    })

                    settings = load_settings()
                    concurrency = int(settings.get("native_chunk_concurrency") or 16)
                    concurrency = max(4, min(concurrency, 32))

                    emit_event("download-progress", {
                        "jobId": job_id,
                        "type": "output",
                        "stream": "stdout",
                        "line": f"Downloading {total_chunks} chunks with {concurrency} parallel high-speed streams..."
                    })

                    out_file = depot_dir / "depot_data.bin"
                    out_fd = os.open(str(out_file), os.O_RDWR | os.O_CREAT, 0o664)
                    progress_lock = threading.Lock()
                    download_state = {
                        "completed_bytes": 0,
                        "done_chunks": 0,
                        "last_emit_time": time.time(),
                        "start_time": time.time()
                    }

                    def chunk_worker(chunk):
                        if active_jobs.get(job_id, {}).get("cancelled"):
                            return False
                        chunk_sha = chunk.get("sha", "")
                        chunk_uncompressed = chunk.get("uncompressed_size", chunk.get("size", 0))
                        chunk_offset = chunk.get("offset", 0)

                        try:
                            raw_chunk = download_chunk(depot_id, chunk_sha)
                            data = process_chunk(raw_chunk, depot_key) if has_key else raw_chunk
                            os.pwrite(out_fd, data, chunk_offset)
                        except Exception as ce:
                            print(f"Chunk error {chunk_sha}: {ce}")

                        with progress_lock:
                            download_state["completed_bytes"] += chunk_uncompressed
                            download_state["done_chunks"] += 1
                            now = time.time()
                            done = download_state["done_chunks"]
                            comp = download_state["completed_bytes"]
                            if now - download_state["last_emit_time"] >= 0.4 or done == total_chunks:
                                download_state["last_emit_time"] = now
                                elapsed = max(0.1, now - download_state["start_time"])
                                speed_mb = (comp / 1024 / 1024) / elapsed
                                pct = round((comp / total_bytes * 100) if total_bytes > 0 else 100, 1)
                                emit_event("download-progress", {
                                    "jobId": job_id,
                                    "type": "output",
                                    "stream": "stdout",
                                    "line": f"{pct}% ({done}/{total_chunks} chunks) @ {speed_mb:.2f} MB/s",
                                    "completedBytes": comp,
                                    "totalBytes": total_bytes,
                                    "percent": pct
                                })
                        return True

                    try:
                        with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency) as executor:
                            futures = [executor.submit(chunk_worker, c) for c in chunks]
                            for future in concurrent.futures.as_completed(futures):
                                if active_jobs.get(job_id, {}).get("cancelled"):
                                    executor.shutdown(wait=False, cancel_futures=True)
                                    emit_event("download-progress", {"jobId": job_id, "type": "cancelled"})
                                    return
                    finally:
                        try:
                            os.close(out_fd)
                        except Exception:
                            pass

                except Exception as e:
                    print(f"Depot {depot_id} error: {e}")
                    emit_event("download-progress", {
                        "jobId": job_id,
                        "type": "output",
                        "stream": "stderr",
                        "line": f"Depot {depot_id} error: {e}"
                    })
                    depot_success = False

            results.append({"depotId": depot_id, "success": depot_success})

            emit_event("download-progress", {
                "jobId": job_id,
                "type": "depot_complete",
                "depotId": int(depot_id) if depot_id.isdigit() else depot_id,
                "current": i + 1,
                "total": total_depots
            })

        # Record in history
        hist = load_history()
        hist["entries"].insert(0, {
            "id": job_id,
            "app_id": app_id,
            "game_name": game_name,
            "header_image": config.get("headerImage"),
            "depot_count": total_depots,
            "depots_downloaded": len([r for r in results if r["success"]]),
            "status": "completed",
            "download_dir": str(target_dir),
            "started_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "completed_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "depot_ids": [d.get("depotId") for d in depots]
        })
        save_history(hist)

        active_jobs[job_id]["completed"] = True
        active_jobs[job_id]["status"] = "completed"

        emit_event("download-progress", {
            "jobId": job_id,
            "type": "complete",
            "diag": {"outcome": "complete"},
            "results": results,
            "message": f"Successfully completed download for {game_name}"
        })

    except Exception as e:
        active_jobs[job_id]["status"] = "error"
        active_jobs[job_id]["error"] = str(e)
        emit_event("download-progress", {
            "jobId": job_id,
            "type": "error",
            "message": str(e)
        })

# ---------- Command Dispatcher ----------
def handle_invoke(cmd, args):
    if cmd == "get_settings":
        return load_settings()

    elif cmd == "save_settings":
        settings_data = args.get("settings", args)
        save_settings(settings_data)
        return True

    elif cmd == "get_history":
        return load_history().get("entries", [])

    elif cmd == "clear_history":
        save_history({"entries": []})
        return True

    elif cmd == "remove_history_entry":
        entry_id = args.get("id") or args.get("entryId")
        hist = load_history()
        hist["entries"] = [e for e in hist.get("entries", []) if e.get("id") != entry_id]
        save_history(hist)
        return True

    elif cmd == "record_history_entry":
        entry = args.get("entry", {})
        if entry:
            hist = load_history()
            hist["entries"].insert(0, entry)
            save_history(hist)
        return True

    elif cmd == "get_pending_followup":
        return load_pending_followup()

    elif cmd == "save_pending_followup":
        return save_pending_followup(args.get("followup", args))

    elif cmd == "clear_pending_followup":
        return clear_pending_followup()

    elif cmd == "search_steam_games":
        query = args.get("query", "").strip()
        if not query:
            return []
        url = "https://store.steampowered.com/api/storesearch/?" + urllib.parse.urlencode({
            "term": query, "l": "english", "cc": "US"
        })
        try:
            data = fetch_json(url)
            items = data.get("items", [])
            return [
                {
                    "appId": item.get("id"),
                    "name": item.get("name"),
                    "image": item.get("tiny_image", "")
                }
                for item in items[:15]
            ]
        except Exception:
            return []

    elif cmd == "get_steam_app_info":
        app_id = str(args.get("appId") or args.get("app_id", ""))
        url = f"https://store.steampowered.com/api/appdetails?appids={app_id}"
        try:
            data = fetch_json(url)
            entry = data.get(app_id, {})
            if entry.get("success"):
                d = entry.get("data", {})
                return {
                    "name": d.get("name"),
                    "headerImage": d.get("header_image"),
                    "shortDescription": d.get("short_description"),
                    "type": d.get("type")
                }
        except Exception:
            pass
        return None

    elif cmd in ("fetch_depot_metadata", "fetch_depot_metadata_steam"):
        app_id = str(args.get("appId") or args.get("app_id", ""))
        url = f"https://api.steamcmd.net/v1/info/{app_id}"
        try:
            data = fetch_json(url)
            depots_obj = data.get("data", {}).get(app_id, {}).get("depots", {})
            results = []
            for k, v in depots_obj.items():
                if not k.isdigit():
                    continue
                cfg = v.get("config", {})
                man = v.get("manifests", {}).get("public", {})
                results.append({
                    "depot_id": k,
                    "oslist": cfg.get("oslist"),
                    "osarch": cfg.get("osarch"),
                    "language": cfg.get("language"),
                    "size_bytes": int(man["size"]) if man.get("size") and str(man["size"]).isdigit() else None,
                    "download_bytes": int(man["download"]) if man.get("download") and str(man["download"]).isdigit() else None,
                    "manifest_gid": man.get("gid")
                })
            return results
        except Exception:
            return []

    elif cmd == "recommend_depots":
        depots = args.get("depots", [])
        platform = args.get("platform", "windows").lower()
        lang = args.get("language", "english").lower()
        selected = []
        for d in depots:
            depot_id = str(d.get("depotId") or d.get("depot_id", ""))
            oslist = str(d.get("oslist", "")).lower()
            d_lang = str(d.get("language", "")).lower()
            if oslist and platform not in oslist:
                continue
            if d_lang and d_lang != lang and d_lang != "all":
                continue
            selected.append(depot_id)
        return selected

    elif cmd == "search_repos":
        app_id = str(args.get("appId") or args.get("app_id", ""))
        repos = [{
            "repo": "configured",
            "date": time.strftime("%Y-%m-%d"),
            "sha": None,
            "type": "remote",
            "source": "remote"
        }]
        return {"repos": repos, "sourceProbe": "found"}

    elif cmd == "get_repo_manifests":
        app_id = str(args.get("appId") or args.get("app_id", ""))
        settings = load_settings()
        sources = settings.get("depot_sources", DEFAULT_SETTINGS["depot_sources"])

        # Try sources with quick timeout
        vdf_keys = {}
        manifests = []
        try:
            lua_text = download_file_from_sources(sources, app_id, f"{app_id}.lua")
            parsed = parse_lua_content(lua_text) if lua_text else {"depots": []}
            vdf_text = download_file_from_sources(sources, app_id, "key.vdf")
            vdf_keys = parse_vdf_keys(vdf_text) if vdf_text else {}
            json_text = download_file_from_sources(sources, app_id, f"{app_id}.json")
            sizes = {}
            if json_text:
                try:
                    sizes = extract_depot_sizes(json.loads(json_text))
                except Exception:
                    pass

            for d in parsed.get("depots", []):
                d_id = str(d.get("depot_id"))
                m_id = str(d.get("manifest_id") or "N/A")
                key = d.get("depot_key") or vdf_keys.get(d_id)
                size = d.get("size_bytes") or sizes.get((d_id, m_id))
                manifests.append({
                    "depot_id": d_id,
                    "manifest_id": m_id,
                    "filename": f"{d_id}_{m_id}.manifest",
                    "depot_key": key,
                    "size_bytes": size
                })
        except Exception:
            pass

        # If manifests empty or not found in repos, populate from official SteamCMD
        if not manifests:
            try:
                steamcmd_url = f"https://api.steamcmd.net/v1/info/{app_id}"
                data = fetch_json(steamcmd_url, timeout=6)
                depots_obj = data.get("data", {}).get(str(app_id), {}).get("depots", {})
                for k, v in depots_obj.items():
                    if not k.isdigit():
                        continue
                    man = v.get("manifests", {}).get("public", {})
                    gid = man.get("gid")
                    size = int(man["size"]) if man.get("size") and str(man["size"]).isdigit() else None
                    manifests.append({
                        "depot_id": k,
                        "manifest_id": str(gid) if gid else "N/A",
                        "filename": f"{k}_{gid}.manifest" if gid else f"{k}.manifest",
                        "depot_key": vdf_keys.get(k),
                        "size_bytes": size
                    })
            except Exception as e:
                print(f"SteamCMD fallback error: {e}")

        return {
            "manifests": manifests,
            "has_key_vdf": bool(vdf_keys),
            "key_vdf_filename": "key.vdf" if vdf_keys else None,
            "lua_filename": f"{app_id}.lua",
            "files": [f"{app_id}.lua"],
            "depot_keys": vdf_keys
        }

    elif cmd == "parse_lua_file":
        path = args.get("path", "")
        p = Path(path)
        if not p.exists():
            raise FileNotFoundError(f"File not found: {path}")
        raw = p.read_bytes()
        if p.suffix.lower() == ".st":
            return parse_st_file(raw)
        else:
            return parse_lua_content(raw.decode("utf-8", errors="ignore"))

    elif cmd == "parse_lua_content":
        return parse_lua_content(args.get("content", ""))

    elif cmd == "start_download":
        cfg = args.get("config", args)
        job_id = str(uuid.uuid4())
        dest_dir = cfg.get("downloadDir") or str(Path.home() / "Downloads" / "SteamDownloads")
        app_id = str(cfg.get("mainAppId") or cfg.get("app_id", ""))
        game_name = cfg.get("gameName", f"App {app_id}")
        safe_name = re.sub(r'[<>:"/\\|?*]', '_', game_name)
        target_dir = Path(dest_dir) / f"{app_id} - {safe_name}"

        active_jobs[job_id] = {"cancelled": False, "config": cfg}
        threading.Thread(target=execute_download, args=(job_id, cfg), daemon=True).start()
        return {"jobId": job_id, "downloadDir": str(target_dir)}

    elif cmd == "cancel_download":
        job_id = args.get("jobId") or args.get("job_id")
        if job_id in active_jobs:
            active_jobs[job_id]["cancelled"] = True
        return True

    elif cmd == "pause_download":
        return True

    elif cmd == "detect_executables":
        return detect_executables(args.get("downloadDir", ""))

    elif cmd in ("check_free_space", "get_disk_space"):
        path = args.get("path", str(Path.home()))
        try:
            usage = shutil.disk_usage(path)
            return {
                "free": usage.free,
                "total": usage.total,
                "freeGB": round(usage.free / (1024**3), 2),
                "drive": path,
                "path": path
            }
        except Exception:
            return {"free": 107374182400, "total": 536870912000, "freeGB": 100.0, "drive": "/", "path": path}

    elif cmd == "check_dotnet":
        return {"installed": True, "version": "python-native"}

    elif cmd == "is_shortcut_supported":
        return True

    elif cmd in ("check_for_updates", "get_auto_update_enabled"):
        return None

    elif cmd == "get_covers" or cmd == "check_game_updates":
        return {}

    elif cmd == "get_build_info":
        return {
            "version": "1.5.0-python",
            "channel": "python-standalone",
            "target": sys.platform
        }

    elif cmd == "open_folder":
        folder = args.get("path", "")
        if os.path.exists(folder):
            if sys.platform == "win32":
                os.startfile(folder)
            elif sys.platform == "darwin":
                subprocess.Popen(["open", folder])
            else:
                subprocess.Popen(["xdg-open", folder])
        return True

    elif cmd in ("minimize_window", "maximize_window", "close_window", "restart_app",
                 "set_download_progress", "emit_telemetry_event", "get_telemetry_status",
                 "set_telemetry_consent"):
        return True

    elif cmd.startswith("queue_"):
        return [] if "list" in cmd else True

    elif cmd.startswith("emu_") or cmd.startswith("steam_"):
        return None

    return None

# ---------- HTTP Request Handler ----------
class AppServerHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(BASE_DIR), **kwargs)

    def log_message(self, fmt, *a):
        pass

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self):
        if self.path == "/api/events":
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Connection", "keep-alive")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()

            q = queue.Queue()
            with sse_lock:
                sse_clients.append(q)

            try:
                while True:
                    data = q.get()
                    self.wfile.write(data.encode("utf-8"))
                    self.wfile.flush()
            except (ConnectionResetError, BrokenPipeError):
                with sse_lock:
                    if q in sse_clients:
                        sse_clients.remove(q)
            return

        super().do_GET()

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length) if length > 0 else b"{}"

        if self.path == "/api/invoke":
            try:
                payload = json.loads(body.decode("utf-8"))
                cmd = payload.get("cmd")
                args = payload.get("args", {})
                res = handle_invoke(cmd, args)
                resp_bytes = json.dumps({"data": res}).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.end_headers()
                self.wfile.write(resp_bytes)
            except Exception as e:
                err_bytes = json.dumps({"error": str(e)}).encode("utf-8")
                self.send_response(500)
                self.send_header("Content-Type", "application/json")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.end_headers()
                self.wfile.write(err_bytes)
            return

        elif self.path == "/api/upload_file":
            try:
                data = json.loads(body.decode("utf-8"))
                filename = data.get("name", "uploaded.lua")
                content = data.get("content", "")
                is_base64 = data.get("is_base64", False)
                save_path = TEMP_UPLOADS / filename
                if is_base64:
                    raw_bytes = base64.b64decode(content)
                    save_path.write_bytes(raw_bytes)
                else:
                    save_path.write_text(content, encoding="utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.end_headers()
                self.wfile.write(json.dumps({"path": str(save_path)}).encode("utf-8"))
            except Exception as e:
                self.send_response(500)
                self.end_headers()
                self.wfile.write(json.dumps({"error": str(e)}).encode("utf-8"))
            return

        self.send_response(404)
        self.end_headers()

def run_server(port=8899):
    server = ThreadingHTTPServer(("0.0.0.0", port), AppServerHandler)
    url = f"http://localhost:{port}/index.html"
    print("=" * 60)
    print(" Steam Manifest Downloader (Python Standalone Edition)")
    print(f" Web UI: {url}")
    print(" Compatible with: Linux, Android (Termux/Browser), Windows, macOS")
    print(" Press Ctrl+C to stop.")
    print("=" * 60)
    try:
        webbrowser.open(url)
    except Exception:
        pass
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down server...")
        server.server_close()

if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else 8899
    run_server(port)
